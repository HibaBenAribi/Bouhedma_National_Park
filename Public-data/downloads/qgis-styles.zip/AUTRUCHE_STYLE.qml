<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis autoRefreshMode="Disabled" autoRefreshTime="0" hasScaleBasedVisibilityFlag="0" labelsEnabled="0" layerType="Vector" maxScale="0" minScale="100000000" readOnly="0" simplifyAlgorithm="0" simplifyDrawingHints="1" simplifyDrawingTol="1" simplifyLocal="1" simplifyMaxScale="1" styleCategories="AllStyleCategories" symbologyReferenceScale="-1" version="4.0.3-Norrköping">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal accumulate="0" durationField="NB_INDIV" durationUnit="min" enabled="0" endExpression="" endField="" fixedDuration="0" limitMode="0" mode="0" startExpression="" startField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation binding="Centroid" clamping="Terrain" customToleranceEnabled="1" extrusion="0" extrusionEnabled="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" symbology="Line" type="IndividualFeatures" zoffset="0" zscale="1">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="line">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" enabled="1" id="{b8ce2566-ca8a-4c4c-8e6d-9ff58e24509a}" locked="0" pass="0">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="255,158,23,255,rgb:1,0.6196079,0.0901961,1"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{6f2b5414-4efc-4668-b74f-4118950a6735}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="255,158,23,255,rgb:1,0.6196079,0.0901961,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="182,113,16,255,rgb:0.7142748,0.4425269,0.0644236,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleMarker" enabled="1" id="{f4badfd0-2b8e-4a26-a661-933e5abdc0b9}" locked="0" pass="0">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="255,158,23,255,rgb:1,0.6196079,0.0901961,1"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="182,113,16,255,rgb:0.7142748,0.4425269,0.0644236,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" forceraster="0" referencescale="-1" symbollevels="0" type="singleSymbol">
    <symbols>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="0" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{0e6c7d83-dff5-4f7c-ba8a-b39332f2f5d3}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="0,0,255,0,rgb:0,0,1,0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.26"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="CentroidFill" enabled="1" id="{31ff33f4-0538-4c77-bc1c-7e9b8a079b1c}" locked="0" pass="0">
          <Option type="Map">
            <Option name="clip_on_current_part_only" type="QString" value="0"/>
            <Option name="clip_points" type="QString" value="0"/>
            <Option name="point_on_all_parts" type="QString" value="1"/>
            <Option name="point_on_surface" type="QString" value="0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="@0@1" type="marker">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer class="RasterMarker" enabled="1" id="{2894ccac-7885-422f-9ead-8588ce610ae6}" locked="0" pass="0">
              <Option type="Map">
                <Option name="alpha" type="QString" value="1"/>
                <Option name="angle" type="QString" value="0"/>
                <Option name="fixedAspectRatio" type="QString" value="0"/>
                <Option name="horizontal_anchor_point" type="QString" value="1"/>
                <Option name="imageFile" type="QString" value="C:/Users/Dell/Desktop/GeoAI/WWF_PARC_BOUHEDMA/WWF_TALENT_ACADEMY_2026_BOUHEDMA_DATABASE/qgis_styles/imgs/autruche.png"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="scale_method" type="QString" value="diameter"/>
                <Option name="size" type="QString" value="12"/>
                <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="size_unit" type="QString" value="MM"/>
                <Option name="vertical_anchor_point" type="QString" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol alpha="1" clip_to_extent="1" force_rhr="0" frame_rate="10" is_animated="0" name="" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleFill" enabled="1" id="{b90aeb64-1ed3-46aa-a52a-404e9806587b}" locked="0" pass="0">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="0,0,255,255,rgb:0,0,1,1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255,rgb:0.1372549,0.1372549,0.1372549,1"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.26"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <customproperties>
    <Option type="Map">
      <Option name="QFieldSync/action" type="QString" value="copy"/>
      <Option name="QFieldSync/attachment_naming" type="QString" value="{}"/>
      <Option name="QFieldSync/attribute_editing_locked_expression" type="QString" value=""/>
      <Option name="QFieldSync/cloud_action" type="QString" value="offline"/>
      <Option name="QFieldSync/feature_addition_locked_expression" type="QString" value=""/>
      <Option name="QFieldSync/feature_deletion_locked_expression" type="QString" value=""/>
      <Option name="QFieldSync/geometry_editing_locked_expression" type="QString" value=""/>
      <Option name="QFieldSync/photo_naming" type="QString" value="{}"/>
      <Option name="QFieldSync/relationship_maximum_visible" type="QString" value="{}"/>
      <Option name="QFieldSync/tracking_distance_requirement_minimum_meters" type="int" value="30"/>
      <Option name="QFieldSync/tracking_erroneous_distance_safeguard_maximum_meters" type="int" value="1"/>
      <Option name="QFieldSync/tracking_measurement_type" type="int" value="0"/>
      <Option name="QFieldSync/tracking_time_requirement_interval_seconds" type="int" value="30"/>
      <Option name="QFieldSync/value_map_button_interface_threshold" type="int" value="0"/>
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration type="Map">
      <Option name="QgsGeometryGapCheck" type="Map">
        <Option name="allowedGapsBuffer" type="double" value="0"/>
        <Option name="allowedGapsEnabled" type="bool" value="false"/>
        <Option name="allowedGapsLayer" type="QString" value=""/>
      </Option>
    </checkConfiguration>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <referencingLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="SITE_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NAME_FR">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NAME_EN">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="SPEC_CODE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="SPEC_COMM">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="SPEC_SCI">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="TAXON_GRP">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="IUCN_STAT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="NB_INDIV">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="AGE_CLASS">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="HABITAT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="PURPOSE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="DATE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="SITE_ID" index="0" name=""/>
    <alias field="NAME_FR" index="1" name=""/>
    <alias field="NAME_EN" index="2" name=""/>
    <alias field="SPEC_CODE" index="3" name=""/>
    <alias field="SPEC_COMM" index="4" name=""/>
    <alias field="SPEC_SCI" index="5" name=""/>
    <alias field="TAXON_GRP" index="6" name=""/>
    <alias field="IUCN_STAT" index="7" name=""/>
    <alias field="NB_INDIV" index="8" name=""/>
    <alias field="AGE_CLASS" index="9" name=""/>
    <alias field="HABITAT" index="10" name=""/>
    <alias field="PURPOSE" index="11" name=""/>
    <alias field="DATE" index="12" name=""/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="SITE_ID"/>
    <default applyOnUpdate="0" expression="" field="NAME_FR"/>
    <default applyOnUpdate="0" expression="" field="NAME_EN"/>
    <default applyOnUpdate="0" expression="" field="SPEC_CODE"/>
    <default applyOnUpdate="0" expression="" field="SPEC_COMM"/>
    <default applyOnUpdate="0" expression="" field="SPEC_SCI"/>
    <default applyOnUpdate="0" expression="" field="TAXON_GRP"/>
    <default applyOnUpdate="0" expression="" field="IUCN_STAT"/>
    <default applyOnUpdate="0" expression="" field="NB_INDIV"/>
    <default applyOnUpdate="0" expression="" field="AGE_CLASS"/>
    <default applyOnUpdate="0" expression="" field="HABITAT"/>
    <default applyOnUpdate="0" expression="" field="PURPOSE"/>
    <default applyOnUpdate="0" expression="" field="DATE"/>
  </defaults>
  <constraints>
    <constraint constraints="0" exp_strength="0" field="SITE_ID" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="NAME_FR" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="NAME_EN" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="SPEC_CODE" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="SPEC_COMM" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="SPEC_SCI" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="TAXON_GRP" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="IUCN_STAT" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="NB_INDIV" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="AGE_CLASS" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="HABITAT" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="PURPOSE" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="DATE" notnull_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="SITE_ID"/>
    <constraint desc="" exp="" field="NAME_FR"/>
    <constraint desc="" exp="" field="NAME_EN"/>
    <constraint desc="" exp="" field="SPEC_CODE"/>
    <constraint desc="" exp="" field="SPEC_COMM"/>
    <constraint desc="" exp="" field="SPEC_SCI"/>
    <constraint desc="" exp="" field="TAXON_GRP"/>
    <constraint desc="" exp="" field="IUCN_STAT"/>
    <constraint desc="" exp="" field="NB_INDIV"/>
    <constraint desc="" exp="" field="AGE_CLASS"/>
    <constraint desc="" exp="" field="HABITAT"/>
    <constraint desc="" exp="" field="PURPOSE"/>
    <constraint desc="" exp="" field="DATE"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column hidden="0" name="SITE_ID" type="field" width="-1"/>
      <column hidden="0" name="NAME_FR" type="field" width="-1"/>
      <column hidden="0" name="NAME_EN" type="field" width="-1"/>
      <column hidden="0" name="SPEC_CODE" type="field" width="-1"/>
      <column hidden="0" name="SPEC_COMM" type="field" width="-1"/>
      <column hidden="0" name="SPEC_SCI" type="field" width="-1"/>
      <column hidden="0" name="TAXON_GRP" type="field" width="-1"/>
      <column hidden="0" name="IUCN_STAT" type="field" width="-1"/>
      <column hidden="0" name="NB_INDIV" type="field" width="-1"/>
      <column hidden="0" name="AGE_CLASS" type="field" width="-1"/>
      <column hidden="0" name="HABITAT" type="field" width="-1"/>
      <column hidden="0" name="PURPOSE" type="field" width="-1"/>
      <column hidden="0" name="DATE" type="field" width="-1"/>
      <column hidden="1" type="actions" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
Les formulaires QGIS peuvent avoir une fonction Python qui est appelée lorsque le formulaire est
ouvert.

Utilisez cette fonction pour ajouter une logique supplémentaire à vos formulaires.

Entrez le nom de la fonction dans le champ 
"Fonction d'initialisation Python".
Voici un exemple:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field editable="1" name="AGE_CLASS"/>
    <field editable="1" name="DATE"/>
    <field editable="1" name="HABITAT"/>
    <field editable="1" name="IUCN_STAT"/>
    <field editable="1" name="NAME_EN"/>
    <field editable="1" name="NAME_FR"/>
    <field editable="1" name="NB_INDIV"/>
    <field editable="1" name="PURPOSE"/>
    <field editable="1" name="SITE_ID"/>
    <field editable="1" name="SPEC_CODE"/>
    <field editable="1" name="SPEC_COMM"/>
    <field editable="1" name="SPEC_SCI"/>
    <field editable="1" name="TAXON_GRP"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="AGE_CLASS"/>
    <field labelOnTop="0" name="DATE"/>
    <field labelOnTop="0" name="HABITAT"/>
    <field labelOnTop="0" name="IUCN_STAT"/>
    <field labelOnTop="0" name="NAME_EN"/>
    <field labelOnTop="0" name="NAME_FR"/>
    <field labelOnTop="0" name="NB_INDIV"/>
    <field labelOnTop="0" name="PURPOSE"/>
    <field labelOnTop="0" name="SITE_ID"/>
    <field labelOnTop="0" name="SPEC_CODE"/>
    <field labelOnTop="0" name="SPEC_COMM"/>
    <field labelOnTop="0" name="SPEC_SCI"/>
    <field labelOnTop="0" name="TAXON_GRP"/>
  </labelOnTop>
  <reuseLastValuePolicy>
    <field name="AGE_CLASS" reuseLastValuePolicy="NotAllowed"/>
    <field name="DATE" reuseLastValuePolicy="NotAllowed"/>
    <field name="HABITAT" reuseLastValuePolicy="NotAllowed"/>
    <field name="IUCN_STAT" reuseLastValuePolicy="NotAllowed"/>
    <field name="NAME_EN" reuseLastValuePolicy="NotAllowed"/>
    <field name="NAME_FR" reuseLastValuePolicy="NotAllowed"/>
    <field name="NB_INDIV" reuseLastValuePolicy="NotAllowed"/>
    <field name="PURPOSE" reuseLastValuePolicy="NotAllowed"/>
    <field name="SITE_ID" reuseLastValuePolicy="NotAllowed"/>
    <field name="SPEC_CODE" reuseLastValuePolicy="NotAllowed"/>
    <field name="SPEC_COMM" reuseLastValuePolicy="NotAllowed"/>
    <field name="SPEC_SCI" reuseLastValuePolicy="NotAllowed"/>
    <field name="TAXON_GRP" reuseLastValuePolicy="NotAllowed"/>
  </reuseLastValuePolicy>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"NAME_FR"</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
